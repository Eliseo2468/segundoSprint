/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.boncortproyect.igu;

import com.mycompany.boncortproyect.logica.Cliente;
import com.mycompany.boncortproyect.logica.Tickets;
import org.apache.poi.ss.usermodel.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Formatter;
import java.util.Set;
import java.util.List;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.filechooser.FileSystemView;
import javax.swing.table.DefaultTableModel;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class Reportes extends javax.swing.JInternalFrame {

    String color="#FF5252";
    java.awt.Color colorPrimario = java.awt.Color.decode(color);
    
    public Reportes() {
        initComponents();
        estiloBotones();
        //agregando datos a la tabla
        agregarDatos();
        
        //agregando listener a la tabla si se toca
        tbTickets.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            
            int filaSelect=tbTickets.getSelectedRow();
            btnGenerar.setEnabled(false);

        }
        });
        
        //si el usuario preciona enter
        tbTickets.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    
                    int filaSelect = tbTickets.getSelectedRow();
                    modificarDatos(filaSelect);
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {
                
            }
        });
    }

    //funcion utilizada para crear la tabla y agregar datos de la base de datos en ella
    public void agregarDatos(){
        //se le ponen los parametros de cada columna
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Contenido");
        model.addColumn("Numero");
        model.addColumn("Peso");
        model.addColumn("Precio");
        model.addColumn("Envia");
        model.addColumn("Recibe");
        
       
        //conexion con la base de datos
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager em= emf.createEntityManager();

        Query query = em.createQuery("SELECT c FROM Tickets c");
        List<Tickets> listaTickets = query.getResultList();
        
        //foreach para llenar la tabla con la listaTickets
        for (Tickets ticket : listaTickets) {
                Object[] row = {ticket.getId_tickets(),ticket.getContenido(),ticket.getNum_vinieta(),ticket.getPeso_paquete(),ticket.getPrecio_paquete(),ticket.getClienteEn().getNombre_Cliente(),ticket.getClienteRe().getNombre_Cliente()};
                model.addRow(row);
        }
        tbTickets.setModel(model);
        model.fireTableDataChanged();
        
        
    }
    
    //funcion para actualizar la tabla
    public void actualizarDatos(){
        DefaultTableModel model = (DefaultTableModel) tbTickets.getModel();
        model.setRowCount(0);
        model.setColumnCount(0);
        agregarDatos();
    }
    
    //funcion utilizada para modificar los datos de la tabla tanto de ella misma como de la base de datos
    private void modificarDatos(int filaSelec){
      
        if(filaSelec!=-1){
            //recolectando datos a modificar
        int id_tickets=Integer.parseInt(tbTickets.getValueAt(filaSelec,0).toString());
        String Contenido=tbTickets.getValueAt(filaSelec, 1).toString();
        String Num_vinieta=tbTickets.getValueAt(filaSelec, 2).toString();
        float peso_paquete=Float.parseFloat(tbTickets.getValueAt(filaSelec, 3).toString());
        float precio_paquete=Float.parseFloat(tbTickets.getValueAt(filaSelec, 4).toString());
        
        
        //conexion con la base de datos
        EntityManagerFactory emfE=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager emE=emfE.createEntityManager();
        
        //retornando el valor a 
        emE.getTransaction().begin();
            Tickets modfTickets=emE.find(Tickets.class, id_tickets);
        //verificar errores
        try{
            
            try{
            //modificando datos
            modfTickets.setContenido(Contenido);
            modfTickets.setNum_vinieta(Num_vinieta);
            modfTickets.setPeso_paquete(peso_paquete);
            modfTickets.setPrecio_paquete(precio_paquete);
            emE.getTransaction().commit(); 
            
            }finally{
                //cerrando conexion con la base de datos
                emE.close();
                emfE.close();
                JOptionPane.showMessageDialog(this, "Ticket actualizado correctamente", "Éxito", JOptionPane.OK_OPTION);
                //se actualizan los datos de la vista
                actualizarDatos();
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(this, "Error al actualizar Ticket", "Error", JOptionPane.ERROR);
        }
        }
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tbTickets = new javax.swing.JTable();
        btnGenerar = new javax.swing.JButton();

        tbTickets.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tbTickets);

        btnGenerar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGenerar.setText("Generar Reportes");
        btnGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(263, 263, 263)
                        .addComponent(btnGenerar, javax.swing.GroupLayout.PREFERRED_SIZE, 559, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 956, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54)
                .addComponent(btnGenerar, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(188, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarActionPerformed
        String directorio=selecionarDirectorio();
        crearExcelTickets(directorio);
        crearControlEntregas(directorio);
        crearManifiesto(directorio);
        EliminarTickets();
        
    }//GEN-LAST:event_btnGenerarActionPerformed
    
    private void crearExcelTickets(String directorio){
        int Row=0;
        int Column=0;
        int contador=0;
        //creando libro de excel que se utilizara
        Workbook libro = new XSSFWorkbook();
        //definimos la fecha actual
        LocalDate fechaActual=LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        //convirtiendolo a string
        String fechaActualS=fechaActual.format(formatter);
        //dandole nombre al archivo
        final String nombreArchivo = "Tickets_"+fechaActualS;
        //nombre de la hoja de tranajo
        Sheet hoja = libro.createSheet("Hoja 1"); 
        
        //conexion con la base de datos
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager em= emf.createEntityManager();

        Query query = em.createQuery("SELECT c FROM Tickets c");
        List<Tickets> listaTickets = query.getResultList();
        
        try {
        
        for(Tickets ticket: listaTickets){
           
         
        for(int i=0+Row;i<12+Row;i++){
            Row Fila = hoja.createRow(i);
            
            for(int j=0+Column;j<3+Column;j++){
                //instanciando filas y celdas
                Cell Celda = Fila.createCell(j);
                //estilos de los encabezados
                CellStyle styleHeader = libro.createCellStyle();
                styleHeader.cloneStyleFrom(estiloEncabezados(libro));
                //estilos de los Datos
                CellStyle styleDatos=libro.createCellStyle();
                styleDatos.cloneStyleFrom(estiloDatos(libro));
                //estilos de los Datos de numero y peso
                CellStyle styleDatosNP=libro.createCellStyle();
                styleDatosNP.cloneStyleFrom(estiloDatosPesoNumero(libro));
                
                //datos del ticket
                String numT=ticket.getNum_vinieta();
                String nombreEnvia=ticket.getClienteEn().getNombre_Cliente();
                String nombreRecibe=ticket.getClienteRe().getNombre_Cliente();
                String DireccionEnvia=ticket.getClienteEn().getDireccion_cliente();
                String DireccionRecibe=ticket.getClienteRe().getDireccion_cliente();
                String Contenido=ticket.getContenido();
                String Precio=String.valueOf(ticket.getPrecio_paquete());
                String Peso=String.valueOf(ticket.getPeso_paquete());
                
                // valores a las celdas de encabezado
                if(i == 0+Row && j == 0+Column) {
                    Celda.setCellValue("N°");
                } else if(i == 0+Row && j == 1+Column) {
                    Celda.setCellValue("SENDING");
                } else if(i == 0+Row && j == 2+Column) {
                    Celda.setCellValue("SHIP TO");
                } else if(i == 4+Row && j == 1+Column) {
                    Celda.setCellValue("CONTAINS");
                } else if(i == 5+Row && j == 2+Column) {
                    Celda.setCellValue("REQUESTED  YES     NO");
                } else if(i == 6+Row && j == 2+Column) {
                    Celda.setCellValue("                                      ✔");
                }
                
                // valores a las celdas de datos del cliente
                if(i == 1+Row && j == 0+Column) {
                    Celda.setCellValue(numT);
                } else if(i == 1+Row && j == 1+Column) {
                    Celda.setCellValue(nombreEnvia);
                } else if(i == 1+Row && j == 2+Column) {
                    Celda.setCellValue(nombreRecibe);
                } else if(i == 2+Row && j == 1+Column) {
                    Celda.setCellValue(DireccionEnvia);
                } else if(i == 2+Row && j == 2+Column) {
                    Celda.setCellValue(DireccionRecibe);
                } else if(i == 5+Row && j == 1+Column) {
                    Celda.setCellValue(Contenido);
                } else if(i == 7+Row && j == 2+Column) {
                    Celda.setCellValue("$ "+Precio);
                } else if(i == 9+Row && j == 0+Column) {
                    Celda.setCellValue("N°"+numT);
                } else if(i == 9+Row && j == 2+Column) {
                    Celda.setCellValue(Peso+"L");
                }
                
                // aplicando estilo de encabezado a las celdas especificas
                if((i == 0+Row && j <= 2+Column) || (i == 4+Row && j == 1+Column) || (i == 5+Row && j == 2+Column) || (i == 6+Row && j == 2+Column)) {
                    if(j==2+Column){
                        styleHeader.setBorderRight(BorderStyle.THICK);
                    }
                    if(i==11+Row){
                        
                        styleHeader.setBorderBottom(BorderStyle.THICK);
                    }
                    Celda.setCellStyle(styleHeader);
                }
                
                // aplicando estilo de los datos a las celdas especificas
                if((i == 1+Row && j <= 2+Column) || (i == 2+Row && j <= 2+Column) || (i==5+Row && j==1+Column) || (i==7+Row && j==2+Column)) {
                    if(j==2+Column){
                        styleDatos.setBorderRight(BorderStyle.THICK);
                    }
                    
                    Celda.setCellStyle(styleDatos);
                }
                // aplicando estilo de los datos a las celdas de numero y peso
                if(i>=9+Row && i<=11+Row){
                    if(j==2+Column){
                        styleDatosNP.setBorderRight(BorderStyle.THICK);
                    }
                    styleDatosNP.setBorderBottom(BorderStyle.THICK);
                    Celda.setCellStyle(styleDatosNP);
                }
                
                //aplicando bordes a celdas vacias
                if((i==3+Row && j==2+Column) || (i==4+Row && j==2+Column) || (i==8+Row && j==2+Column)){
                    CellStyle bordes=libro.createCellStyle();
                    bordes.setBorderRight(BorderStyle.THICK);
                    Celda.setCellStyle(bordes);
                }
                
                
                  
            }
        }
        //fusionando celdas necesarias
        hoja.addMergedRegion(new CellRangeAddress(2+Row, 3+Row, 1+Column, 1+Column));
        hoja.addMergedRegion(new CellRangeAddress(2+Row, 3+Row, 2+Column, 2+Column));
        hoja.addMergedRegion(new CellRangeAddress(5+Row, 8+Row, 1+Column, 1+Column));
        hoja.addMergedRegion(new CellRangeAddress(9+Row, 11+Row, 0+Column, 1+Column));
        hoja.addMergedRegion(new CellRangeAddress(9+Row, 11+Row, 2+Column, 2+Column));
        //dandole tamaño a la columna en base al tamaño del texto
        hoja.autoSizeColumn(0+Column);
        hoja.autoSizeColumn(1+Column);
        hoja.autoSizeColumn(2+Column);
        
        Row+=12;
        
        
        }
        //dandole direccion donde se guardaran los archivos
        File directorioActual = new File(directorio);
        String ubicacionArchivoSalida = directorioActual.getCanonicalPath() + File.separator + nombreArchivo + ".xlsx";
        
        //escribiendo en el .xlsx
        FileOutputStream outputStream = new FileOutputStream(ubicacionArchivoSalida);
        libro.write(outputStream);
        libro.close();
        em.close();
        emf.close();
    } catch (IOException e) {
        e.printStackTrace(); // Imprime la traza de la excepción para depuración
    }
    }
    
    private void crearControlEntregas(String directorio){
        //lista de los nombres de los encabezados
        List<String>listaEncabezado=new ArrayList<>(){{
            add("M");
            add("N°");
            add("Recive");
            add("Envia");
            add("Contenido");
            add("Libras");
            add("N°/pag");
            
        }};
        
        //creando libro de excel que se utilizara
        Workbook libro = new XSSFWorkbook();
        //definimos la fecha actual
        LocalDate fechaActual=LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        //convirtiendolo a string
        String fechaActualS=fechaActual.format(formatter);
        //dandole nombre al archivo
        final String nombreArchivo = "Control_"+fechaActualS;
        //nombre de la hoja de tranajo
        Sheet hoja = libro.createSheet("Hoja 1"); 
        
        //conexion con la base de datos
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager em= emf.createEntityManager();

        Query query = em.createQuery("SELECT c FROM Tickets c");
        List<Tickets> listaTickets = query.getResultList();
        Set<String> TickestVistos = new HashSet<>();
        
        //ordenando por numero de ticket
        Collections.sort(listaTickets, Comparator.comparing(Tickets::getNum_vinieta));
        
        //combinando los mismos numeros
        for (Tickets ticket : listaTickets) {
            String numTicket = ticket.getNum_vinieta();

            // Verifica si ya existe este tickett
            if (TickestVistos.contains(numTicket)) {
                // Si sí, elimina este ticket
                ticket.setNum_vinieta("");
                ticket.setClienteEn(null);
                ticket.setClienteRe(null);
            } else {
                // Si no, marca esta vinieta como vista
                TickestVistos.add(numTicket);
            }
        }
        
        try{
             
                for(int i=0;i<listaTickets.size()+1;i++){
                    Row Fila = hoja.createRow(i);//creacion de la fila
                    
                    for(int j=0;j<7;j++){
                        Cell celda=Fila.createCell(j);//creacion de la celda donde se escribira
                        //estilos de los encabezados
                        CellStyle styleHeader = libro.createCellStyle();
                        styleHeader.cloneStyleFrom(estiloEncabezadosEntregas(libro));
                        //estilos de los datos
                        CellStyle styleDatos = libro.createCellStyle();
                        styleDatos.cloneStyleFrom(estiloDatosEntregas(libro));
                        
                        //encabezado
                        if(i==0){
                          celda.setCellValue(listaEncabezado.get(j));
                          celda.setCellStyle(styleHeader);//dandole el estilo al encabezado
                        }else{
                            
                             //datos
                             if(j==1){//numero
                             celda.setCellValue(listaTickets.get(i-1).getNum_vinieta());
                             celda.setCellStyle(styleDatos);
                             } else if(j==2){//Recive
                                 
                                 if(listaTickets.get(i-1).getClienteRe()==null){
                                     celda.setCellValue("");
                                     celda.setCellStyle(styleDatos);
                                 }else{
                                     celda.setCellValue(listaTickets.get(i-1).getClienteRe().getNombre_Cliente()+"\n"+listaTickets.get(i-1).getClienteRe().getTelefono_cliente());  
                                     celda.setCellStyle(styleDatos);
                                 }
                             
                             } else if(j==3){//Envia
                                 
                                 if(listaTickets.get(i-1).getClienteEn()==null){
                                     celda.setCellValue("");
                                     celda.setCellStyle(styleDatos);
                                 }else{
                                     celda.setCellValue(listaTickets.get(i-1).getClienteEn().getNombre_Cliente());  
                                     celda.setCellStyle(styleDatos);
                                 }
                                 
                             } else if(j==4){//contenido
                             celda.setCellValue(listaTickets.get(i-1).getContenido());  
                             celda.setCellStyle(styleDatos);
                             } else if(j==5){//peso
                             celda.setCellValue(listaTickets.get(i-1).getPeso_paquete());
                             celda.setCellStyle(styleDatos);
                             }else{//colocando los estilos a los campos vacios
                                 celda.setCellValue("");
                                 celda.setCellStyle(styleDatos);
                             }
                             
                             if(i==listaTickets.size()){//colocando ultimos bordes
                                 
                             CellStyle celdasBajas=libro.createCellStyle();
                             celdasBajas.cloneStyleFrom(estiloDatosEntregas(libro));
                             celdasBajas.setBorderBottom(BorderStyle.THIN);
                             celdasBajas.setBottomBorderColor(IndexedColors.BLACK.getIndex());
                             celda.setCellStyle(celdasBajas);
                             
                             }
                        }
   
                    }
                    
                }
                //adaptando texto a la celda
                for(int i=0;i<9;i++){
                    hoja.autoSizeColumn(i);
                }        
            
            //dandole direccion donde se guardaran los archivos
            File directorioActual = new File(directorio);
            String ubicacionArchivoSalida = directorioActual.getCanonicalPath() + File.separator + nombreArchivo + ".xlsx";

            //escribiendo en el .xlsx
            FileOutputStream outputStream = new FileOutputStream(ubicacionArchivoSalida);
            libro.write(outputStream);
            libro.close();
            em.close();
            emf.close();
        }catch (IOException e){
            e.printStackTrace(); // Imprime la traza de la excepción para depuración        
    }
        
        
    }
    
    private void crearManifiesto(String directorio){        
       
        //creando libro de excel que se utilizara
        Workbook libro = new XSSFWorkbook();
        //definimos la fecha actual
        LocalDate fechaActual=LocalDate.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        //convirtiendolo a string
        String fechaActualS=fechaActual.format(formatter);
        //dandole nombre al archivo
        final String nombreArchivo = "Manifiesto_"+fechaActualS;
        //nombre de la hoja de tranajo
        Sheet hoja = libro.createSheet("Hoja 1"); 
        
        //conexion con la base de datos
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager em= emf.createEntityManager();

        Query query = em.createQuery("SELECT c FROM Tickets c");
        List<Tickets> listaTickets = query.getResultList();
        Set<String> TickestVistos = new HashSet<>();
        
        //ordenando por numero de ticket
        Collections.sort(listaTickets, Comparator.comparing(Tickets::getNum_vinieta));
        
        Map<String, Tickets> ticketMap = new HashMap<>();

        // Agrupar los tickets por número de viñeta en el mapa
        for (Tickets ticket : listaTickets) {
            String numVinieta = ticket.getNum_vinieta();
            if (ticketMap.containsKey(numVinieta)) {//comprobando si el numero de la viñeta es igual
                Tickets existingTicket = ticketMap.get(numVinieta);
                //separando por cada valor
                String contenido1=uniendoContenidos(existingTicket.getContenido(),ticket.getContenido());//lista de contenidos 1
                
                existingTicket.setContenido(contenido1);//combinando contenidos de los dos tickets
                existingTicket.setPrecio_paquete(existingTicket.getPrecio_paquete() + ticket.getPrecio_paquete());//sumando el precio de los dos tickets
            } else {
                ticket.setContenido(uniendoContenidos(ticket.getContenido(), ""));
                ticketMap.put(numVinieta, ticket);
            }
        }

        // Limpiando y agregando nueva lista 
        listaTickets.clear();
        listaTickets.addAll(ticketMap.values());
        
        //indice de la mitad
        int indiceMitad = (int) Math.ceil((double) listaTickets.size() / 2);
        
        //dividiendo la lista en 2
        List<Tickets>listaT1=listaTickets.subList(0, indiceMitad);
        List<Tickets>listaT2=listaTickets.subList(indiceMitad, listaTickets.size());
        //variable para aumentar las filas
        int Rows=0;
        try{

            /*
            //Encabezado
            for(int i=0;i<4+Rows;i++){
                Row Fila = hoja.createRow(i);//creacion de la fila
                
                for(int j=0;j<5;j++){
                    Cell Celda=Fila.createCell(j);//creacion de la celda donde se escribira
                    
                    if(i==0 && j==3){
                        Celda.setCellValue("");
                        Celda.setCellStyle(estiloEncabezados(libro));
                    } else if(i==1 && j==2){
                        Celda.setCellValue("URB San Roberto pol 3 cas N9°");
                        Celda.setCellStyle(estiloDatos(libro));
                    } else if(i==1 && j==4){
                        Celda.setCellValue("8113 Russell Rd");
                        Celda.setCellStyle(estiloDatos(libro));
                    } else if(i==2 && j==2){
                        Celda.setCellValue("San miguel, San miguel, El salvador");
                        Celda.setCellStyle(estiloDatos(libro));
                    } else if(i==2 && j==4){
                        Celda.setCellValue("Alexandria Va 22309");
                        Celda.setCellStyle(estiloDatos(libro));
                    } else if(i==3 && j==2){
                        Celda.setCellValue("(503)7730-3977,(503)7736-2793");
                        Celda.setCellStyle(estiloDatos(libro));
                    } else if(i==3 && j==4){
                        Celda.setCellValue("(703)725-2403,(703)504-8077");
                        Celda.setCellStyle(estiloDatos(libro));
                    }
                }
                        
            }*/
            
        //primeras columnas de listas
        for(Tickets ticket: listaT1){
            
            
            
            for(int i=4+Rows;i<12+Rows;i++){
                    Row Fila = hoja.createRow(i);//creacion de la fila
                    
                    //datos del ticket
                    String numT=ticket.getNum_vinieta();
                    String nombreEnvia=ticket.getClienteEn().getNombre_Cliente();
                    String nombreRecibe=ticket.getClienteRe().getNombre_Cliente();
                    String DireccionEnvia=ticket.getClienteEn().getDireccion_cliente();
                    String DireccionRecibe=ticket.getClienteRe().getDireccion_cliente();
                    String Contenido=ticket.getContenido();
                    String Precio=String.valueOf(ticket.getPrecio_paquete());
                    
                    
                    for(int j=0;j<3;j++){
                        Cell Celda=Fila.createCell(j);//creacion de la celda donde se escribira
                        
                        if(j>=0 && j<3){
                            
                            // valores a las celdas de encabezado
                            if(i == 4+Rows && j == 0) {
                                Celda.setCellValue("N°");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloEncabezados(libro),true));
                                Celda.setCellStyle(style);
                            } else if(i == 4+Rows && j == 1) {
                                Celda.setCellValue("SENDING");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesTop(libro, estiloEncabezados(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 4+Rows && j == 2) {
                                Celda.setCellValue("SHIP TO");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesTop(libro, estiloEncabezados(libro),true));
                                Celda.setCellStyle(style);
                            } else if(i == 8+Rows && j == 1) {
                                Celda.setCellValue("CONTAINS");
                                Celda.setCellStyle(estiloEncabezados(libro));
                            } else if(i == 9+Rows && j == 2) {
                                Celda.setCellValue("REQUESTED  YES     NO");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloEncabezados(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 10+Rows && j == 2) {
                                Celda.setCellValue("                                      ✔");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloEncabezados(libro)));
                                Celda.setCellStyle(style);
                            }
                            
                            // valores a las celdas de datos del cliente
                            if(i == 5+Rows && j == 0) {//numero de ticket
                                Celda.setCellValue(numT);
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloEncabezados(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 5+Rows && j == 1) {//nombre del cliente que envia
                                Celda.setCellValue(nombreEnvia);
                                Celda.setCellStyle(estiloDatos(libro));
                            } else if(i == 5+Rows && j == 2) {//combre del cliente que recibe
                                Celda.setCellValue(nombreRecibe);
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloDatos(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 6+Rows && j == 1) {//direccion del cliente que envia
                                Celda.setCellValue(separandoDirecciones(DireccionEnvia));
                                Celda.setCellStyle(estiloDatos(libro));
                            } else if(i == 6+Rows && j == 0) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 6+Rows && j == 2) {//direccion del cliente que recibe
                                Celda.setCellValue(separandoDirecciones(DireccionRecibe));
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloDatos(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 7+Rows && j == 0) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 7+Rows && j == 2) {//celda vacia
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloDatos(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 8+Rows && j == 0) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 8+Rows && j == 2) {//celda vacia
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloDatos(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 9+Rows && j == 0) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 9+Rows && j == 1) {//contenido del páquete
                                Celda.setCellValue(Contenido);
                                Celda.setCellStyle(estiloDatos(libro));
                            } else if(i == 10+Rows && j == 0) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 11+Rows && j == 0) {//celda vacia
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesBot(libro, estiloDatos(libro),false, true));
                                Celda.setCellStyle(style);  
                            } else if(i == 11+Rows && j == 1) {//celda vacia
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesBot(libro, estiloDatos(libro),false,false));
                                Celda.setCellStyle(style);  
                            } else if(i == 11+Rows && j == 2) {//precio del paquete
                                Celda.setCellValue("$ "+Precio);
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesBot(libro, estiloDatos(libro),true,false));
                                Celda.setCellStyle(style);  
                            }
                            
                        } else{
                            
                        }
                    }
            }
            //aumentar 8 filas mas
            Rows+=8;
        }
        
        //reiniciando filas
        Rows=0;
        
        //segunda columnas de listas
        for(Tickets ticket: listaT2){
            
            for(int i = 4 + Rows; i <= 12 + Rows && i <= hoja.getLastRowNum(); i++){
                    Row Fila = hoja.getRow(i);//creacion de la fila
                    
                    //datos del ticket
                    String numT=ticket.getNum_vinieta();
                    String nombreEnvia=ticket.getClienteEn().getNombre_Cliente();
                    String nombreRecibe=ticket.getClienteRe().getNombre_Cliente();
                    String DireccionEnvia=ticket.getClienteEn().getDireccion_cliente();
                    String DireccionRecibe=ticket.getClienteRe().getDireccion_cliente();
                    String Contenido=ticket.getContenido();
                    String Precio=String.valueOf(ticket.getPrecio_paquete());
                    
                    
                    for(int j=3;j<6;j++){
                        
                        Cell Celda=Fila.createCell(j);//creacion de la celda donde se escribira
                            
                            // valores a las celdas de encabezado
                            if(i == 4+Rows && j == 3) {
                                Celda.setCellValue("N°");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloEncabezados(libro),true));
                                Celda.setCellStyle(style);
                            } else if(i == 4+Rows && j == 4) {
                                Celda.setCellValue("SENDING");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesTop(libro, estiloEncabezados(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 4+Rows && j == 5) {
                                Celda.setCellValue("SHIP TO");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesTop(libro, estiloEncabezados(libro),true));
                                Celda.setCellStyle(style);
                            } else if(i == 8+Rows && j == 4) {
                                Celda.setCellValue("CONTAINS");
                                Celda.setCellStyle(estiloEncabezados(libro));
                            } else if(i == 9+Rows && j == 5) {
                                Celda.setCellValue("REQUESTED  YES     NO");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloEncabezados(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 10+Rows && j == 5) {
                                Celda.setCellValue("                                      ✔");
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloEncabezados(libro)));
                                Celda.setCellStyle(style);
                            }
                            
                            // valores a las celdas de datos del cliente
                            if(i == 5+Rows && j == 3) {//numero de ticket
                                Celda.setCellValue(numT);
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloEncabezados(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 5+Rows && j == 4) {//nombre del cliente que envia
                                Celda.setCellValue(nombreEnvia);
                                Celda.setCellStyle(estiloDatos(libro));
                            } else if(i == 5+Rows && j == 5) {//combre del cliente que recibe
                                Celda.setCellValue(nombreRecibe);
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloDatos(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 6+Rows && j == 4) {//direccion del cliente que envia
                                Celda.setCellValue(separandoDirecciones(DireccionEnvia)); 
                                Celda.setCellStyle(estiloDatos(libro));
                            } else if(i == 6+Rows && j == 3) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 6+Rows && j == 5) {//direccion del cliente que recibe
                                Celda.setCellValue(separandoDirecciones(DireccionRecibe));
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloDatos(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 7+Rows && j == 3) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 7+Rows && j == 5) {//celda vacia
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloDatos(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 8+Rows && j == 3) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 8+Rows && j == 5) {//celda vacia
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesRight(libro, estiloDatos(libro)));
                                Celda.setCellStyle(style);
                            } else if(i == 9+Rows && j == 3) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 9+Rows && j == 4) {//contenido del páquete
                                Celda.setCellValue(Contenido);
                                Celda.setCellStyle(estiloDatos(libro));
                            } else if(i == 10+Rows && j == 3) {//celda vacia
                               //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesLeft(libro, estiloDatos(libro),false));
                                Celda.setCellStyle(style);
                            } else if(i == 11+Rows && j == 3) {//celda vacia
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesBot(libro, estiloDatos(libro),false, true));
                                Celda.setCellStyle(style);  
                            } else if(i == 11+Rows && j == 4) {//celda vacia
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesBot(libro, estiloDatos(libro),false,false));
                                Celda.setCellStyle(style);  
                            } else if(i == 11+Rows && j == 5) {//precio del paquete
                                Celda.setCellValue("$ "+Precio);
                                //agregando estilos
                                CellStyle style=libro.createCellStyle();
                                style.cloneStyleFrom(bordesBot(libro, estiloDatos(libro),true,false));
                                Celda.setCellStyle(style);  
                                 
                                 
                            }
                            
                            
                        
                    }
            }
            //aumentar 8 filas mas
            Rows+=8;
        }
        
        
        
        for(int i=0;i<6;i++){
            
            hoja.autoSizeColumn(i);    
            
        }
        
        
        
        //dandole direccion donde se guardaran los archivos
        File directorioActual = new File(directorio);
        String ubicacionArchivoSalida = directorioActual.getCanonicalPath() + File.separator + nombreArchivo + ".xlsx";

        //escribiendo en el .xlsx
        FileOutputStream outputStream = new FileOutputStream(ubicacionArchivoSalida);
        libro.write(outputStream);
        libro.close();
        em.close();
        emf.close();   
        }catch (IOException e){
            e.printStackTrace(); // Imprime la traza de la excepción para depuración        
        }
    }
    
    private String selecionarDirectorio(){
        String selectedDirectoryPath=null;
        JFileChooser fileChooser = new JFileChooser(FileSystemView.getFileSystemView().getFileSystemView().getHomeDirectory());

        // Configura el file chooser para seleccionar solo directorios
        fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);

        int returnValue = fileChooser.showSaveDialog(null);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            // Obtiene la ruta del directorio seleccionado
            selectedDirectoryPath = fileChooser.getSelectedFile().getAbsolutePath();

        } else {
            System.out.println("No se seleccionó ningún directorio.");
        }
        
        return selectedDirectoryPath;
    }
    
    private CellStyle estiloEncabezadosEntregas(Workbook libro){
        CellStyle style=libro.createCellStyle();
        //hacinedo que el texto se adapte a la celda
        style.setWrapText(true);
        
        //dandole una fuente y tamaño a la celda
        Font font = libro.createFont();
        font.setFontName("Arial");
        font.setBold(true);
        font.setFontHeightInPoints((short) 11);
        style.setFont(font);
        //bordes
        style.setBorderTop(BorderStyle.THIN);
        style.setTopBorderColor(IndexedColors.BLACK.getIndex());

        style.setBorderBottom(BorderStyle.THIN);
        style.setBottomBorderColor(IndexedColors.BLACK.getIndex());

        style.setBorderLeft(BorderStyle.THIN);
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());

        style.setBorderRight(BorderStyle.THIN);
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        
        return style;
    }
    
    private CellStyle estiloDatosEntregas(Workbook libro){
        CellStyle style=libro.createCellStyle();
        //hacinedo que el texto se adapte a la celda
        style.setWrapText(true);
        
        //dandole una fuente y tamaño a la celda
        Font font = libro.createFont();
        font.setFontName("Arial");
        font.setFontHeightInPoints((short) 11);
        style.setFont(font);
        //bordes

        style.setBorderLeft(BorderStyle.THIN);
        style.setLeftBorderColor(IndexedColors.BLACK.getIndex());

        style.setBorderRight(BorderStyle.THIN);
        style.setRightBorderColor(IndexedColors.BLACK.getIndex());
        
        return style;
    }
    //estilos para bordes
    private CellStyle bordesTop(Workbook libro, CellStyle style,boolean aux){
        CellStyle style2= libro.createCellStyle();
        style2.cloneStyleFrom(style);
        
        style2.setBorderTop(BorderStyle.THIN);
        style2.setTopBorderColor(IndexedColors.BLACK.getIndex());
        
        if(aux){
            style2.setBorderRight(BorderStyle.THIN);
            style2.setRightBorderColor(IndexedColors.BLACK.getIndex());
        }
        
        return style2;
    }
    private CellStyle bordesBot(Workbook libro, CellStyle style,boolean aux, boolean aux2){
        CellStyle style2= libro.createCellStyle();
        style2.cloneStyleFrom(style);
        
        style2.setBorderBottom(BorderStyle.THIN);
        style2.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        
        if(aux){
            style2.setBorderRight(BorderStyle.THIN);
            style2.setRightBorderColor(IndexedColors.BLACK.getIndex());
        }
        if(aux2){
            style2.setBorderLeft(BorderStyle.THIN);
            style2.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        }
        
        return style2;
    }
    private CellStyle bordesLeft(Workbook libro, CellStyle style, boolean aux){
        CellStyle style2= libro.createCellStyle();
        style2.cloneStyleFrom(style);
        
        style2.setBorderLeft(BorderStyle.THIN);
        style2.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        
        if(aux){
            style2.setBorderTop(BorderStyle.THIN);
            style2.setTopBorderColor(IndexedColors.BLACK.getIndex());
        }
        
        return style2;
    }
    private CellStyle bordesRight(Workbook libro, CellStyle style){
        CellStyle style2= libro.createCellStyle();
        style2.cloneStyleFrom(style);
        
        style2.setBorderRight(BorderStyle.THIN);
        style2.setRightBorderColor(IndexedColors.BLACK.getIndex());
        
        return style2;
    }
    
    private CellStyle estiloEncabezados(Workbook libro){
        CellStyle style=libro.createCellStyle();
        //hacinedo que el texto se adapte a la celda
        style.setWrapText(true);
        
        //dandole una fuente y tamaño a la celda
        Font font = libro.createFont();
        font.setFontName("Arial");
        font.setBold(true);
        font.setFontHeightInPoints((short) 11);
        style.setFont(font);
        
        
        return style;
    }
    
    private CellStyle estiloDatos(Workbook libro){
        CellStyle style=libro.createCellStyle();
        //hacinedo que el texto se adapte a la celda
        style.setWrapText(true);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        //dandole una fuente y tamaño a la celda
        Font font = libro.createFont();
        font.setFontName("Arial");
        font.setFontHeightInPoints((short) 11);
        style.setFont(font);
        
        
        return style;
    }
    private CellStyle estiloDatosPesoNumero(Workbook libro){
        CellStyle style=libro.createCellStyle();
        //hacinedo que el texto se adapte a la celda
        style.setWrapText(true);
        style.setVerticalAlignment(VerticalAlignment.TOP);
        //dandole una fuente y tamaño a la celda
        Font font = libro.createFont();
        font.setFontName("Arial");
        font.setFontHeightInPoints((short) 36);
        font.setBold(true);
        style.setFont(font);
        
        
        return style;
    }
    
    private String uniendoContenidos(String contenido1, String contenido2){
        
        String contenido=contenido1+","+contenido2;
        //String textoSinEspacios = contenido.replaceAll("\\s", "");//quitando los espacios en el texto
        String[] partes=contenido.split(",");//separandolos por comas
        String contenidoSeparado="";
        
        HashSet<String> conjunto = new HashSet<>(Arrays.asList(partes));//eliminando datos repetidos
        
        String[] partesLimpia = conjunto.toArray(new String[0]);
        
        
        int contador = 0; // Variable para contar las partes
        int tamañoArreglo=partesLimpia.length;
        
        if(tamañoArreglo!=1){//comprobando si solo hay un dato
            
            for (String parte : partesLimpia) {
            contenidoSeparado += parte + ","; // Agrega la parte actual seguida de una coma
            contador++;
            
                if (contador == 2) {//si el contador llega a 2 dara un salto de linea
                    contenidoSeparado += "\n";
                    contador = 0; // Reinicia el contador
                }
            }

            if (contador > 0) {
                contenidoSeparado += ",";
            }
            
        }else{
            contenidoSeparado=contenido1;
        }
        
        
        
        return contenidoSeparado;
    }
    private String separandoDirecciones(String contenido){
        String[] partes=contenido.split(",");//separandolos por comas
        String contenidoSeparado="";

            for (String parte : partes) {
                
                contenidoSeparado += parte+"\n";
            }

            
            
        return contenidoSeparado;
    }
    
    private void estiloBotones(){        
        
        btnGenerar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                
                    // Cambiar el color de fondo cuando el ratón entra al área del botón
                    btnGenerar.setBackground(colorPrimario);
                    btnGenerar.setForeground(java.awt.Color.white);
                
            }

            @Override
            public void mouseExited(MouseEvent e) {
                
                    // Restaurar el color de fondo cuando el ratón sale del área del botón
                    btnGenerar.setBackground(UIManager.getColor("control"));
                    btnGenerar.setForeground(java.awt.Color.BLACK);
                
            }
        });
    }
    
    private void EliminarTickets() {
        // conexión con la base de datos
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("BonCortPU");
        EntityManager em = emf.createEntityManager();

        // Iniciar una transacción
        em.getTransaction().begin();

        // Consultar todos los tickets
        Query query = em.createQuery("SELECT c FROM Tickets c");
        List<Tickets> listaTickets = query.getResultList();

        // Eliminar cada ticket individualmente
        for (Tickets ticket : listaTickets) {
            em.remove(ticket);
        }

        // Confirmar la transacción para aplicar los cambios
        em.getTransaction().commit();

        // Cerrar el EntityManager y el EntityManagerFactory
        em.close();
        emf.close();
        actualizarDatos();
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGenerar;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbTickets;
    // End of variables declaration//GEN-END:variables
}
