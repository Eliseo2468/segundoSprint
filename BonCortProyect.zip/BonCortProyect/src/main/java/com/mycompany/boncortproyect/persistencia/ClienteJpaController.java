/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.boncortproyect.persistencia;

import com.mycompany.boncortproyect.logica.Cliente;
import java.io.Serializable;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import com.mycompany.boncortproyect.logica.Tickets;
import com.mycompany.boncortproyect.persistencia.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Cesar
 */
public class ClienteJpaController implements Serializable {

    public ClienteJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    public ClienteJpaController() {
        emf=Persistence.createEntityManagerFactory("BonCortPU");
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Cliente cliente) {
        if (cliente.getTiketsRe() == null) {
            cliente.setTiketsRe(new ArrayList<Tickets>());
        }
        if (cliente.getTiketsEn() == null) {
            cliente.setTiketsEn(new ArrayList<Tickets>());
        }
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            List<Tickets> attachedTiketsRe = new ArrayList<Tickets>();
            for (Tickets tiketsReTicketsToAttach : cliente.getTiketsRe()) {
                tiketsReTicketsToAttach = em.getReference(tiketsReTicketsToAttach.getClass(), tiketsReTicketsToAttach.getId_tickets());
                attachedTiketsRe.add(tiketsReTicketsToAttach);
            }
            cliente.setTiketsRe(attachedTiketsRe);
            List<Tickets> attachedTiketsEn = new ArrayList<Tickets>();
            for (Tickets tiketsEnTicketsToAttach : cliente.getTiketsEn()) {
                tiketsEnTicketsToAttach = em.getReference(tiketsEnTicketsToAttach.getClass(), tiketsEnTicketsToAttach.getId_tickets());
                attachedTiketsEn.add(tiketsEnTicketsToAttach);
            }
            cliente.setTiketsEn(attachedTiketsEn);
            em.persist(cliente);
            for (Tickets tiketsReTickets : cliente.getTiketsRe()) {
                Cliente oldClienteReOfTiketsReTickets = tiketsReTickets.getClienteRe();
                tiketsReTickets.setClienteRe(cliente);
                tiketsReTickets = em.merge(tiketsReTickets);
                if (oldClienteReOfTiketsReTickets != null) {
                    oldClienteReOfTiketsReTickets.getTiketsRe().remove(tiketsReTickets);
                    oldClienteReOfTiketsReTickets = em.merge(oldClienteReOfTiketsReTickets);
                }
            }
            for (Tickets tiketsEnTickets : cliente.getTiketsEn()) {
                Cliente oldClienteEnOfTiketsEnTickets = tiketsEnTickets.getClienteEn();
                tiketsEnTickets.setClienteEn(cliente);
                tiketsEnTickets = em.merge(tiketsEnTickets);
                if (oldClienteEnOfTiketsEnTickets != null) {
                    oldClienteEnOfTiketsEnTickets.getTiketsEn().remove(tiketsEnTickets);
                    oldClienteEnOfTiketsEnTickets = em.merge(oldClienteEnOfTiketsEnTickets);
                }
            }
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Cliente cliente) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente persistentCliente = em.find(Cliente.class, cliente.getId_cliente());
            List<Tickets> tiketsReOld = persistentCliente.getTiketsRe();
            List<Tickets> tiketsReNew = cliente.getTiketsRe();
            List<Tickets> tiketsEnOld = persistentCliente.getTiketsEn();
            List<Tickets> tiketsEnNew = cliente.getTiketsEn();
            List<Tickets> attachedTiketsReNew = new ArrayList<Tickets>();
            for (Tickets tiketsReNewTicketsToAttach : tiketsReNew) {
                tiketsReNewTicketsToAttach = em.getReference(tiketsReNewTicketsToAttach.getClass(), tiketsReNewTicketsToAttach.getId_tickets());
                attachedTiketsReNew.add(tiketsReNewTicketsToAttach);
            }
            tiketsReNew = attachedTiketsReNew;
            cliente.setTiketsRe(tiketsReNew);
            List<Tickets> attachedTiketsEnNew = new ArrayList<Tickets>();
            for (Tickets tiketsEnNewTicketsToAttach : tiketsEnNew) {
                tiketsEnNewTicketsToAttach = em.getReference(tiketsEnNewTicketsToAttach.getClass(), tiketsEnNewTicketsToAttach.getId_tickets());
                attachedTiketsEnNew.add(tiketsEnNewTicketsToAttach);
            }
            tiketsEnNew = attachedTiketsEnNew;
            cliente.setTiketsEn(tiketsEnNew);
            cliente = em.merge(cliente);
            for (Tickets tiketsReOldTickets : tiketsReOld) {
                if (!tiketsReNew.contains(tiketsReOldTickets)) {
                    tiketsReOldTickets.setClienteRe(null);
                    tiketsReOldTickets = em.merge(tiketsReOldTickets);
                }
            }
            for (Tickets tiketsReNewTickets : tiketsReNew) {
                if (!tiketsReOld.contains(tiketsReNewTickets)) {
                    Cliente oldClienteReOfTiketsReNewTickets = tiketsReNewTickets.getClienteRe();
                    tiketsReNewTickets.setClienteRe(cliente);
                    tiketsReNewTickets = em.merge(tiketsReNewTickets);
                    if (oldClienteReOfTiketsReNewTickets != null && !oldClienteReOfTiketsReNewTickets.equals(cliente)) {
                        oldClienteReOfTiketsReNewTickets.getTiketsRe().remove(tiketsReNewTickets);
                        oldClienteReOfTiketsReNewTickets = em.merge(oldClienteReOfTiketsReNewTickets);
                    }
                }
            }
            for (Tickets tiketsEnOldTickets : tiketsEnOld) {
                if (!tiketsEnNew.contains(tiketsEnOldTickets)) {
                    tiketsEnOldTickets.setClienteEn(null);
                    tiketsEnOldTickets = em.merge(tiketsEnOldTickets);
                }
            }
            for (Tickets tiketsEnNewTickets : tiketsEnNew) {
                if (!tiketsEnOld.contains(tiketsEnNewTickets)) {
                    Cliente oldClienteEnOfTiketsEnNewTickets = tiketsEnNewTickets.getClienteEn();
                    tiketsEnNewTickets.setClienteEn(cliente);
                    tiketsEnNewTickets = em.merge(tiketsEnNewTickets);
                    if (oldClienteEnOfTiketsEnNewTickets != null && !oldClienteEnOfTiketsEnNewTickets.equals(cliente)) {
                        oldClienteEnOfTiketsEnNewTickets.getTiketsEn().remove(tiketsEnNewTickets);
                        oldClienteEnOfTiketsEnNewTickets = em.merge(oldClienteEnOfTiketsEnNewTickets);
                    }
                }
            }
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                int id = cliente.getId_cliente();
                if (findCliente(id) == null) {
                    throw new NonexistentEntityException("The cliente with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(int id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cliente cliente;
            try {
                cliente = em.getReference(Cliente.class, id);
                cliente.getId_cliente();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The cliente with id " + id + " no longer exists.", enfe);
            }
            List<Tickets> tiketsRe = cliente.getTiketsRe();
            for (Tickets tiketsReTickets : tiketsRe) {
                tiketsReTickets.setClienteRe(null);
                tiketsReTickets = em.merge(tiketsReTickets);
            }
            List<Tickets> tiketsEn = cliente.getTiketsEn();
            for (Tickets tiketsEnTickets : tiketsEn) {
                tiketsEnTickets.setClienteEn(null);
                tiketsEnTickets = em.merge(tiketsEnTickets);
            }
            em.remove(cliente);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Cliente> findClienteEntities() {
        return findClienteEntities(true, -1, -1);
    }

    public List<Cliente> findClienteEntities(int maxResults, int firstResult) {
        return findClienteEntities(false, maxResults, firstResult);
    }

    private List<Cliente> findClienteEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cliente.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Cliente findCliente(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cliente.class, id);
        } finally {
            em.close();
        }
    }

    public int getClienteCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cliente> rt = cq.from(Cliente.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
