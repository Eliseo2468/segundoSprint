/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package com.mycompany.boncortproyect.igu;

import com.mycompany.boncortproyect.logica.Cliente;
import com.mycompany.boncortproyect.logica.Tickets;
import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.swing.ComboBoxEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

/**
 *
 * @author Roberto Laínez
 */
public class Generar_binietas extends javax.swing.JInternalFrame {

    String color="#FF5252";
    Color colorPrimario = Color.decode(color);
    
    public Generar_binietas() {
        initComponents();
        estiloBotones();
        rellenarDireccionesConEnter();
        initAutoCompleteEnvia();
        initAutoCompleteRecive();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDescripcion = new javax.swing.JTextArea();
        txtEnvia = new javax.swing.JTextField();
        txtRecibe = new javax.swing.JTextField();
        txtDireccionRe = new javax.swing.JTextField();
        txtPeso = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        txtDireccionEn = new javax.swing.JTextField();
        btnGenerar = new javax.swing.JButton();
        txtNumViñeta = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        comboBox = new javax.swing.JComboBox<>();
        comboBox1 = new javax.swing.JComboBox<>();

        jLabel1.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel1.setText("Direccion:");

        jLabel2.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel2.setText("Envia:");

        jLabel3.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel3.setText("Descripcion:");

        jLabel4.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel4.setText("Peso en libras:");

        jLabel5.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel5.setText("Precio:");

        jLabel6.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel6.setText("Recibe:");

        jLabel7.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel7.setText("Direccion:");

        txtDescripcion.setColumns(20);
        txtDescripcion.setRows(5);
        jScrollPane1.setViewportView(txtDescripcion);

        txtEnvia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEnviaActionPerformed(evt);
            }
        });

        txtPeso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtPesoActionPerformed(evt);
            }
        });

        txtDireccionEn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDireccionEnActionPerformed(evt);
            }
        });

        btnGenerar.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        btnGenerar.setText("Generar Biñetas");
        btnGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGenerarActionPerformed(evt);
            }
        });

        txtNumViñeta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNumViñetaActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel8.setText("Numero viñeta:");

        comboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        comboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(135, 135, 135)
                .addComponent(btnGenerar, javax.swing.GroupLayout.PREFERRED_SIZE, 524, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 273, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(comboBox, 0, 358, Short.MAX_VALUE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE)
                    .addComponent(txtEnvia)
                    .addComponent(txtDireccionEn))
                .addGap(18, 29, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtDireccionRe, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(comboBox1, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtRecibe, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 358, Short.MAX_VALUE))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtNumViñeta, javax.swing.GroupLayout.PREFERRED_SIZE, 142, javax.swing.GroupLayout.PREFERRED_SIZE)))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(5, 5, 5)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtEnvia, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtRecibe, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtNumViñeta, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDireccionRe, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPeso, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtDireccionEn, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(btnGenerar, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtPesoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtPesoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtPesoActionPerformed

    private void txtDireccionEnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDireccionEnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDireccionEnActionPerformed

    private void btnGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGenerarActionPerformed
        //recibiendo datos 
        String Envia=txtEnvia.getText();
        String Recibe=txtRecibe.getText();
        String DireccionEn=txtDireccionEn.getText();
        String DireccionRe=txtDireccionRe.getText();
        rellenarDirecciones();
        String Descripcion=txtDescripcion.getText();
        String numViñeta=txtNumViñeta.getText();
        float peso=0.0f;
        float precio=0.0f;
        //comprobar que el peso y precio tengan datos antes de convertir
        if(!txtPrecio.getText().isEmpty() && !txtPeso.getText().isEmpty()){
            //comprobando que si o si sea un tipo flotante
            try{
               peso=Float.parseFloat(txtPeso.getText().toString());
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "peso no valido", "Error", JOptionPane.WARNING_MESSAGE);
            }
            
            try{
               precio=Float.parseFloat(txtPrecio.getText().toString());
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "precio no valido", "Error", JOptionPane.WARNING_MESSAGE);
            }
            
        }
        
        //comprobando que no esten vacios
        if(!Envia.isEmpty() && !Recibe.isEmpty() && !DireccionEn.isEmpty()&& !numViñeta.isEmpty() && !DireccionRe.isEmpty() && !Descripcion.isEmpty() && peso!=0.0f && precio!=0.0f){
            //haceidno uso de la funcion para comprobar si los clientes existen o no
            if(comprobarClientes(Envia,Recibe)){
                //conexion con la unidad de persitencia
                    EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
                    EntityManager em=emf.createEntityManager();
                    
                //try para capturar errores
                try{
                    
                    
                    Tickets ticket= new Tickets();
                    
                    ticket.setNum_vinieta(numViñeta);
                    ticket.setContenido(Descripcion);
                    ticket.setPrecio_paquete(precio);
                    ticket.setPeso_paquete(peso);
                    ticket.setClienteEn(buscarcliente(Envia));
                    ticket.setClienteRe(buscarcliente(Recibe));
                    
                    
                    em.getTransaction().begin();
                    em.persist(ticket);
                    em.getTransaction().commit();
                    
                }catch(Exception e){
                    JOptionPane.showMessageDialog(null, "error al crear la viñeta", "Error", JOptionPane.WARNING_MESSAGE);
                }finally{
                    em.close();
                    emf.close();
                    JOptionPane.showMessageDialog(null, "Viñeta agregada con exito", "Exito", JOptionPane.OK_OPTION);
                    vaciarContenedores();
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "ingrese los nombres correctos", "Error", JOptionPane.WARNING_MESSAGE);
            }
            
        }else{
            JOptionPane.showMessageDialog(null, "faltan datos", "Error", JOptionPane.WARNING_MESSAGE);
        }
    }//GEN-LAST:event_btnGenerarActionPerformed

    private void txtNumViñetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNumViñetaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNumViñetaActionPerformed

    private void txtEnviaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEnviaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtEnviaActionPerformed

//funcion utilizada para comprobar si los clientes existen o no
private boolean comprobarClientes(String clienteEn, String clienteRe){
    boolean Existe=false,cEn=false, cRe=false;
    
    //conexion con la unidad de persistencia
    EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
    EntityManager em=emf.createEntityManager();
    
    //try catch para capturar errores
    try{
        //creando query y recolectando todos los clientes
        TypedQuery<Cliente> query=em.createQuery("SELECT c FROM Cliente c",Cliente.class);
        List<Cliente>listaClientes=query.getResultList();
        
        //bucle para recorrer todos los clientes
        for(Cliente cliente:listaClientes){
            //comprobando si existe el cliente que envia
            if(cliente.getNombre_Cliente().equals(clienteEn)){
                cEn=true;
            }
        }
        
        //bucle para recorrer todos los clientes
        for(Cliente cliente:listaClientes){
            //comprobando si existe el cliente que recibe
            if(cliente.getNombre_Cliente().equals(clienteRe)){
                cRe=true;
            }
        }
        
        //comprobando si los dos existen
        if(cEn==true && cRe==true){
            Existe=true;
        }else{
            //mensaje de error si el cliente que envia no esta en la base de datos
            if(cEn==false){
                JOptionPane.showMessageDialog(null, "Nombre del cliente que envia no valido", "Error", JOptionPane.WARNING_MESSAGE);
            }
            //mensaje de error si el cliente que recibe no esta en la base de datos
            if(cRe==false){
                JOptionPane.showMessageDialog(null, "Nombre del cliente que recibe no valido", "Error", JOptionPane.WARNING_MESSAGE);
            }
        }
        
    }catch(Exception e){
        JOptionPane.showMessageDialog(null, "Error", "Error", JOptionPane.WARNING_MESSAGE);
    }finally{
        em.close();
        emf.close();
    }
    //retornando que los clientes si existes
    return Existe;
}

//funcion utilizada para retornar clientes
private Cliente buscarcliente(String nombre){
    //cliente que envia
    Cliente clienteReturn= new Cliente();
    EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
    EntityManager em=emf.createEntityManager();
    
    //try catch para capturar errores
    try{
        //creando query y recolectando todos los clientes
        TypedQuery<Cliente> query=em.createQuery("SELECT c FROM Cliente c",Cliente.class);
        List<Cliente>listaClientes=query.getResultList();
        
        //bucle para recorrer todos los clientes
        for(Cliente cliente:listaClientes){
            //comprobando si existe el cliente que envia
            if(cliente.getNombre_Cliente().equals(nombre)){
                clienteReturn=cliente;
            }
        }

    }catch(Exception e){
        JOptionPane.showMessageDialog(null, "Error", "Error", JOptionPane.WARNING_MESSAGE);
    }finally{
        em.close();
        emf.close();
    }
    
    return clienteReturn;
}
//funcion utilizada para limpiar los contenedores
private void vaciarContenedores(){
    txtEnvia.setText("");
    txtRecibe.setText("");
    txtDireccionEn.setText("");
    txtDireccionRe.setText("");
    txtNumViñeta.setText("");
    txtDescripcion.setText("");
    txtPeso.setText("");
    txtPrecio.setText("");
    
}

//funcion utilizada para colocar las direcciones automaticamente si el usuario preciona enter
private void rellenarDireccionesConEnter(){
    //si preciona la tecla enter en el textField txtEnvia
    txtEnvia.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    //buscando el cliente
                    Cliente clienteEn= new Cliente();
                    clienteEn=buscarcliente(txtEnvia.getText());
                    
                    txtDireccionEn.setText(clienteEn.getDireccion_cliente());
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {
                // Implementa este método (incluso si no necesitas realizar ninguna acción específica)
            }
        });
    
    //si preciona la tecla enter en el textField txtEnvia
    txtRecibe.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    //buscando el cliente
                    Cliente clienteRe= new Cliente();
                    clienteRe=buscarcliente(txtRecibe.getText());
                    
                    txtDireccionRe.setText(clienteRe.getDireccion_cliente());
                }
            }

            @Override
            public void keyPressed(KeyEvent e) {
                // Implementa este método (incluso si no necesitas realizar ninguna acción específica)
            }
        });
}

//funcion utilizada para colocar las direcciones automaticamente
private void rellenarDirecciones(){
     //buscando el cliente
      Cliente clienteEn= new Cliente();
      clienteEn=buscarcliente(txtEnvia.getText());
                    
      txtDireccionEn.setText(clienteEn.getDireccion_cliente());
      
      //buscando el cliente
      Cliente clienteRe= new Cliente();
      clienteRe=buscarcliente(txtRecibe.getText());
                    
      txtDireccionRe.setText(clienteRe.getDireccion_cliente());
}

private void estiloBotones(){        
        
        btnGenerar.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                
                    // Cambiar el color de fondo cuando el ratón entra al área del botón
                    btnGenerar.setBackground(colorPrimario);
                    btnGenerar.setForeground(Color.white);
                
            }

            @Override
            public void mouseExited(MouseEvent e) {
                
                    // Restaurar el color de fondo cuando el ratón sale del área del botón
                    btnGenerar.setBackground(UIManager.getColor("control"));
                    btnGenerar.setForeground(Color.BLACK);
                
            }
        });
    }
    
private void initAutoCompleteEnvia() {
    //conexion con la base de datos
    EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
    EntityManager em= emf.createEntityManager();

    Query query = em.createQuery("SELECT c FROM Cliente c");
    List<Cliente> listaClientes = query.getResultList();
    List<String> listaNombres=new ArrayList<>();
    
    comboBox.removeAllItems();
    
    for(Cliente cliente : listaClientes){
        listaNombres.add(cliente.getNombre_Cliente());
    }

    // Crear JComboBox con las sugerencias
    for (String nombre : listaNombres) {
    comboBox.addItem(nombre);
    }

    comboBox.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Obtén el elemento seleccionado del JComboBox
        String selectedOption = (String) comboBox.getSelectedItem();
        // Establece el texto del JTextField con la sugerencia seleccionada
        txtEnvia.setText(selectedOption);
        // Oculta el JComboBox después de la selección
        comboBox.setPopupVisible(false);
        rellenarDirecciones();
        }
    });
    
    txtEnvia.addKeyListener(new KeyAdapter() {
    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() != KeyEvent.VK_ENTER) {
            // Obtén el texto ingresado en el JTextField
            String input = txtEnvia.getText().toLowerCase();
            // Filtra las sugerencias basadas en el texto ingresado
            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            for (String suggestion : listaNombres) {
                if (suggestion.toLowerCase().startsWith(input)) {
                    model.addElement(suggestion);
                }
            }
            // Actualiza el modelo del JComboBox
            comboBox.setModel(model);
            // Muestra el JComboBox si hay sugerencias disponibles
            comboBox.setPopupVisible(model.getSize() > 0);
            }
        }
    });
    


    em.close();
    emf.close();
}

private void initAutoCompleteRecive() {
    //conexion con la base de datos
    EntityManagerFactory emf=Persistence.createEntityManagerFactory("BonCortPU");
    EntityManager em= emf.createEntityManager();

    Query query = em.createQuery("SELECT c FROM Cliente c");
    List<Cliente> listaClientes = query.getResultList();
    List<String> listaNombres=new ArrayList<>();
    
    comboBox1.removeAllItems();
    
    for(Cliente cliente : listaClientes){
        listaNombres.add(cliente.getNombre_Cliente());
    }

    // Crear JComboBox con las sugerencias
    for (String nombre : listaNombres) {
    comboBox1.addItem(nombre);
    }

    comboBox1.addActionListener(new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
        // Obtén el elemento seleccionado del JComboBox
        String selectedOption = (String) comboBox1.getSelectedItem();
        // Establece el texto del JTextField con la sugerencia seleccionada
        txtRecibe.setText(selectedOption);
        // Oculta el JComboBox después de la selección
        comboBox1.setPopupVisible(false);
        rellenarDirecciones();
        }
    });
    
    txtRecibe.addKeyListener(new KeyAdapter() {
    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() != KeyEvent.VK_ENTER) {
            // Obtén el texto ingresado en el JTextField
            String input = txtRecibe.getText().toLowerCase();
            // Filtra las sugerencias basadas en el texto ingresado
            DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
            for (String suggestion : listaNombres) {
                if (suggestion.toLowerCase().startsWith(input)) {
                    model.addElement(suggestion);
                }
            }
            // Actualiza el modelo del JComboBox
            comboBox1.setModel(model);
            // Muestra el JComboBox si hay sugerencias disponibles
            comboBox1.setPopupVisible(model.getSize() > 0);
            }
        }
    });
    


    em.close();
    emf.close();
}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGenerar;
    private javax.swing.JComboBox<String> comboBox;
    private javax.swing.JComboBox<String> comboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtDescripcion;
    private javax.swing.JTextField txtDireccionEn;
    private javax.swing.JTextField txtDireccionRe;
    private javax.swing.JTextField txtEnvia;
    private javax.swing.JTextField txtNumViñeta;
    private javax.swing.JTextField txtPeso;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtRecibe;
    // End of variables declaration//GEN-END:variables
}
